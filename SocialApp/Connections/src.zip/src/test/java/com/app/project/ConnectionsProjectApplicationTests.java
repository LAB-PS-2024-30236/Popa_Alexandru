package com.app.project;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class ConnectionsProjectApplicationTests {

	@Test
	void contextLoads() {
	}

}
